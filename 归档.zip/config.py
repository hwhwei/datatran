categories = {}
cn2en = {}
en2cn = {}
nan = ['', 'nan', '0', '无']


def register(c):
    categories[c.__name__] = c
    cn2en[c.cid3_name_cn] = c.__name__
    en2cn[c.__name__] = c.cid3_name_cn
    assert len(c.eval_attr_ids) == len(c.eval_attr_names)
    return c

def parse_string(s: str):
    s = s.strip().split()
    ids, names = [], []
    i = 0
    while i<len(s):
        try:
            int(s[i])
            ids.append(s[i])
            names.append(s[i+1])
            i += 2
        except:
            i += 1
    return ids, names


@register
class Keyboard:
    cid3_name_cn = "键盘"
    eval_attr_ids = ['5078', '3184', '15018', '4709', '4708', '2379', '14280']
    eval_attr_names = ["数字键盘", "类型", "背光灯效", "轴体品牌", "轴体类型", "连接方式", "鼠标接口"]

@register
class Mouse:
    cid3_name_cn = "鼠标"
    eval_attr_ids = ["291", "2379", "2338"]
    eval_attr_names = ["尺寸", "连接方式", "颜色"]

@register
class Lens:
    cid3_name_cn = "镜头"
    eval_attr_ids = ["391", "999", "514", "1191", "1017", "13799", "315", "1137"]
    eval_attr_names = ["卡口", "最大光圈", "滤镜直径", "画幅", "自动对焦马达", "适用机身类型", "镜头类型", "防抖"]

@register
class Printer:
    cid3_name_cn = "打印机"
    eval_attr_ids = ['754', '431', '445', '446', '13949', '5345', '524', '350']
    eval_attr_names = ["无边距打印", "扫描类型", "来电显示", "话筒", "自动双面扫描", "耗材类型", "幅面", "打印机类型"]

@register
class Notebook: #注意事项如下
    cid3_name_cn = "笔记本"
    eval_attr_ids = ['3576', '14764', '1254', '14794', '149', '27', '14740', '933', '14749', '14745', '3581', '13550', '3570', '14431', '3716', '3078', '5283', '567.1', '83', '24', '82', '3568', '33', '944', '2327', '567', '6', '2', '14748', '13854', '1917', '507']
    eval_attr_names = ['CPU类型', 'M.2接口数量', 'SATA接口数量', 'USB3.1', '内存容量', '内存类型', '固态硬盘（SSD）', '处理器', '处理器加速频率', '处理器基准频率', '局域网', '屏幕刷新率', '屏幕类型', '屏幕色域', '待机时长', '摄像头', '显卡型号', '显卡类型.1', '显存位宽', '显存容量', '显存类型', '显示比例', '显示端口', '最大支持容量', '屏幕分辨率', '显卡类型', '系列', '系统', '线程数', '理论续航时间', '键盘', '触摸屏']

@register
class Laptop: #注意事项如下
    cid3_name_cn = "笔记本"
    eval_attr_ids = ['3576', '14764', '1254', '14794', '149', '27', '14740', '933', '14749', '14745', '3581', '13550', '3570', '14431', '3716', '3078', '5283', '567.1', '83', '24', '82', '3568', '33', '944', '2327', '567', '6', '2', '14748', '13854', '1917', '507']
    eval_attr_names = ['CPU类型', 'M.2接口数量', 'SATA接口数量', 'USB3.1', '内存容量', '内存类型', '固态硬盘（SSD）', '处理器', '处理器加速频率', '处理器基准频率', '局域网', '屏幕刷新率', '屏幕类型', '屏幕色域', '待机时长', '摄像头', '显卡型号', '显卡类型.1', '显存位宽', '显存容量', '显存类型', '显示比例', '显示端口', '最大支持容量', '屏幕分辨率', '显卡类型', '系列', '系统', '线程数', '理论续航时间', '键盘', '触摸屏']

@register
class GamingComputer:
    cid3_name_cn = "游戏本"
    eval_attr_ids, eval_attr_names = parse_string("UPC	SKU	品牌	型号	3576	CPU类型	14744	CPU集成显卡	1254	SATA接口数量	149	内存容量	27	内存类型	3613	分辨率	14740	固态硬盘（SSD）	933	处理器	5	CPU型号	13550	屏幕刷新率	3570	屏幕类型	14431	屏幕色域	28	插槽数量	5283	显卡型号	567	显卡类型	14793	显卡芯片供应商	24	显存容量	3568	显示比例	33	显示端口	944	最大支持容量	14741	机械硬盘	383	核心数	2327	屏幕分辨率	3184	类型	6	系列	13854	理论续航时间")

@register
class Microphone:
    cid3_name_cn = "麦克风"
    eval_attr_ids = ['292','8054','2202','2636','8051',"8277","3184"]
    eval_attr_names = "传输方式 	伴奏输入	使用方式	供电方式	扬声方式	指向特征	类型	".split()
    drop_columns = ['连接主体','适用场景']
    attrs_black_list = drop_columns

@register
class InkBox:
    cid3_name_cn = "墨盒"
    eval_attr_ids, eval_attr_names = parse_string("UPC	SKU	品牌	型号	878	类别	3184	类型	2314	规格			")

@register
class Desktop:
    cid3_name_cn = "台式机"
    eval_attr_ids, eval_attr_names = parse_string("UPC	SKU	品牌	型号	149	内存容量	3613	分辨率	933	处理器	244	屏幕尺寸	210	平台	5283	显卡型号	24	显存容量	136	显示器尺寸	327	显示芯片	13257	机箱大小	3184	类型	25	硬盘容量	2	系统	26	转速	1917	键盘	329	鼠标	1169	芯片组")

@register
class Drone:
    cid3_name_cn = "无人机"
    eval_attr_ids, eval_attr_names = parse_string("UPC	SKU	品牌	型号	13080	主体类型	12505	实时图传质量	12504	感知系统类型	3078	摄像头	12503	最大信号有效距离	13368	最大航行时间	12501	最大飞行时间	其他备注		")

@register
class Cartridge:
    cid3_name_cn = "硒鼓"
    eval_attr_ids, eval_attr_names = parse_string("UPC	SKU	品牌	型号	3184	类型	2314	规格	878	类别	")

@register
class AIOPC: #all in one pc
    cid3_name_cn = "一体机"
    eval_attr_ids, eval_attr_names = parse_string("UPC	SKU	品牌	型号	149	内存容量	933	处理器	3570	屏幕类型	5283	显卡型号	567	显卡类型	24	显存容量	25	硬盘容量	2	系统	其他备注")
