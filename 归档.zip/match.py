import pandas as pd
import numpy as np
from config import nan

'''
1. 品牌一致才会计算相似度
'''


def calculate_similarity(attrs1, attrs2):
    assert len(attrs2) == len(attrs1)
    a = [str(attr1) for attr1, attr2 in zip(attrs1, attrs2) if str(attr1) == str(attr2) and str(attr1) not in nan]
    b = [str(attr) for attr in attrs1 if str(attr) not in nan]
    return len(a) / (len(b) + 1e-12), a, b


def mergeCols(col1, col2=None):  # 以col1为基准
    if col2 is None:
        col2 = ['' for _ in range(len(col1))]
    res = []
    for i, j in zip(col1, col2):
        k = str(i) if str(i) not in nan else str(j)
        res.append(k if k not in nan else 'NULL')
    return res


def get_dict(category):  #
    df_attrs = pd.read_excel("attrs.xlsx", sheet_name=category)
    val2attr = {}
    mmap = {}  # multiple choices map
    for t, attr, val in df_attrs[["维护方式", "属性名", "属性值名称"]].values:
        val2attr[str(val)] = attr
        if "单" not in t.strip():
            if attr not in mmap:
                mmap[attr] = set()
            mmap[attr].add(val)
    return mmap, val2attr  # key_attrs = set(val2attr.values()), cloumns: 全部属性


# cate, cmp_key_attr, head_temp, head_sku, key_attrs[cate], tail_cols
def match(category, cmp_key_attr, head_tmp, head_sku, key_attrs,
          tail_cols):  # columns: (head_attrs, key_attrs, extra_attrs, tail_attrs)
    skuDF = pd.read_csv('sku_pool/cid3=%s_30/part-00000' % category, header=None, delimiter='\t')
    skuDF = skuDF.applymap(lambda x: x.split(':')[1] if ':' in str(x) else x) #预处理，过滤冒号
    tempDF = pd.read_csv('std_template/cid3=%s_30/part-00000' % category, header=None, delimiter='\t')

    _length_tmp = len(tempDF.columns)
    _length_tmp_head = len(head_tmp)
    _length__tail = len(tail_cols)
    _length_sku = len(skuDF.columns)
    _length_sku_head = len(head_sku)
    _brand_index_sku = 3 #_length_sku - _length__tail
    _brand_index_tmp = 3
    _brand_index_tmp2 = _length_tmp - _length__tail

    d1 = {i: head_sku[i] for i in range(_length_sku_head)}
    d1.update({i + _length_sku_head: key_attrs[i] for i in range(len(key_attrs))})
    skuDF.rename(columns=d1, inplace=True)
    d2 = {i: head_tmp[i] for i in range(_length_tmp_head)}
    d2.update({i + _length_tmp_head: key_attrs[i] for i in range(len(key_attrs))})
    tempDF.rename(columns=d2, inplace=True)

    template_ids = tempDF['skuid'].values

    if cmp_key_attr:  # 关键属性
        columns_tmp = [_length_tmp_head + 1 + i for i in range(len(key_attrs))]
        columns_sku = [_length_sku_head + 1 + i for i in range(len(key_attrs))]
    else:  # 全部属性
        columns_tmp = [_length_tmp_head + 1 + i for i in range(_length_tmp - _length_tmp_head - _length__tail)]
        columns_sku = [_length_sku_head + 1 + i for i in range(_length_sku - _length_sku_head - _length__tail)]

    topK = 3
    threshold = 0.7
    results = []
    for i in range(len(skuDF)):
        #print(i)
        sku = skuDF.iloc[i, columns_sku].values.tolist()
        brand_sku = skuDF.iloc[i, _brand_index_sku]
        scores = [[-1, 0, "", ""] for _ in range(topK)]  # (j, score)
        for j in range(len(tempDF)):
            brand_tmp = tempDF.iloc[j, _brand_index_tmp]
            brand_tmp2 = tempDF.iloc[j, _brand_index_tmp2]
            if brand_tmp != brand_sku or brand_tmp2 != brand_sku:
                continue
            tmp = tempDF.iloc[j, columns_tmp].values.tolist()
            score, a, b = calculate_similarity(sku, tmp)
            if score > threshold and score >= scores[-1][1]:
                scores[-1] = [j, score, a, b]
                scores.sort(key=lambda x: x[1], reverse=True)
        results.append(
            [(str(template_ids[i]), str(round(_score, 5)), ','.join(a), ','.join(b)) if i >= 0 else (['', '', "", " "]) for
             i, _score, a, b in scores])

    results = np.asarray(results)
    for i in range(topK):
        skuDF['UPC' + str(i + 1)] = results[:, i, 0]
        skuDF['Score' + str(i + 1)] = results[:, i, 1]
        if i == 0:
            skuDF["相同核心属性"] = results[:, i, 2]
            skuDF["分子"] = [len(_.split(',')) if _ else 0 for _ in results[:, i, 2]]
            skuDF["分母"] = [len(_.split(',')) if _ else 0 for _ in results[:, i, 3]]

    columns_save = ['skuid', 'skuname', '分子', '分母'] + key_attrs + ['UPC1', 'Score1', '相同核心属性', 'UPC2', 'Score2', 'UPC3',
                                                              'Score3']
    skuDF[columns_save].to_csv('results/%s_1.txt' % category, index=False, header=True, sep='\t')
