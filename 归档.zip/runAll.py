from multiprocessing import Process
from match import match
from config import en2cn


def main():
    cmp_key_attr = True
    #categories = "AIOPC Desktop GamingComputer Cartridge Drone InkBox Keyboard Lens Microphone Mouse Notebook".strip().split() #["Lens"]
    categories = "Cartridge Keyboard Microphone".strip().split()
    head_temp =  "skuid 1 2 brandTmpl 4 upc".strip().split() #"skuid	标题	 cid3	品牌	型号	upc".strip().split()
    head_sku = "skuid skuname 2 brand 4 5 6".strip().split() #"skuid 标题  cid3  upc upc是否合规 upc是否在模板 cid3名".strip().split()
    tail_cols = "brandtmpl2 x1 x2 x3 x4".strip().split()  #"sku品牌 sku型号 colour  size".strip().split()
    key_attrs = {}
    with open("cid3_attr_names.txt") as f:
        line = f.readline()
        while line:
            if line.startswith("后面的核心属性按cid3依次为"):
                line = f.readline()
                while line != '\n':
                    line = line.strip().split()
                    key_attrs[line[0]] = line[1:]
                    line = f.readline()
                break
            line = f.readline()

    p_list = []
    for cate in categories:
        # match(cate, cmp_key_attr, head_temp, head_sku, key_attrs[en2cn[cate]], tail_cols)
        p = Process(target=match, args=(cate, cmp_key_attr, head_temp, head_sku, key_attrs[en2cn[cate]], tail_cols))
        p.start()
        p_list.append(p)

    for p in p_list:
        p.join()

    print("Task Finished!")


if __name__ == '__main__':
    main()
